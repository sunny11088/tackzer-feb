import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../assets/img/common/trackzer-white.svg";
import Faq from "../../components/Faq/Faq";
import Clients from "../../components/Clients/Clients";
import Cta from "../../components/Cta/Cta";
import Testimonials from "../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'MCC Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'MCC Panel' },
  ],
};

const productData = {
  "title": "MCC Panel",
  "tagline": "Design & Innovation | Advanced Mechanism",
  "aboutproduct": "Trackzer Switchgears Pvt. Ltd. manufactures state-of-the-art MCC Panels, incorporating the latest technologies for efficient motor control and power management. These panels ensure precise and reliable control over motor-driven processes.",
  "image": productImage,
  "ogImage": "ogImage",
  "inquiryLink": "https://example.com/static-link",
  "specialFeatures": [
    "Advanced Mechanism for Precise Motor Control",
    "High-Capacity Design for Industrial Motors",
    "Customizable Options for Different Applications",
    "Reliable and Long-lasting Performance",
    "Integration with VFDs and PLCs for Automation",
    "Compact and Easy-to-Install Design",
    "Robust Construction for Industrial Environments",
    "Safety Features Including Overload Protection",
    "Versatile and Flexible for Various Motor Control Needs"
  ],
};

const HvacMccPanel = () => {
  return (
      <React.Fragment>
        <Helmet>
          <title>MCC Panel</title>
          <meta name="description" content="Design & Innovation | Advanced Mechanism" />
          <meta name="keywords" content="MCC Panel, motor control, power management, Trackzer Switchgears, VFD integration, PLC integration, industrial motors, customizable panels, reliable performance" />
          <meta property="og:title" content="MCC Panel" />
          <meta property="og:description" content="Trackzer Switchgears Pvt. Ltd. manufactures state-of-the-art MCC Panels, incorporating the latest technologies for efficient motor control and power management. These panels ensure precise and reliable control over motor-driven processes." />
          <meta property="og:image" content="ogImage" />
          <meta property="og:type" content="website" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta name="inquiry-link" content="https://example.com/static-link" />
        </Helmet>


        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default HvacMccPanel;
