import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../assets/img/common/about-img.png';
import ogImage from '../../assets/img/og-image.png';
import Relatedproducts from "../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../assets/img/common/trackzer-white.svg";
import Faq from "../../components/Faq/Faq";
import Clients from "../../components/Clients/Clients";
import Cta from "../../components/Cta/Cta";
import Testimonials from "../../components/Testimonials/Testimonials";

const bannerData = {
  bgImage: bgImage,
  heading: 'About Us',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'main-lt-pcc-panel' },
  ],
};

const productData = {
  title: "L.T. Panel - Unmatched Quality | Boost Performance",
  tagline: "Trackzer Switchgears Pvt. Ltd. offers high-quality L.T. Panels that enhance electrical distribution and optimize system performance.",
  specialFeatures: [
    "Superior Construction",
    "Assured & Optimal Performance",
    "Customized Options Available",
    "Minimum Maintenance",
    "Precision Engineered",
    "High-Quality Materials and Components",
    "Reliable Performance for Various Applications",
    "Long-lasting and Durable Design",
    "Enhanced Protection and Safety Features"
  ],
  aboutproduct: "These L.T. Panels are designed to receive power from transformers or generators and distribute it effectively to various devices. Ideal for industrial and residential applications, ensuring steady power distribution and optimal operational efficiency.",
  image: productImage,
  ogImage: ogImage,
  inquiryLink: "https://example.com/static-link"
};

const WaterSystemMccPanel = () => {
  const {
    title,
    tagline,
    specialFeatures,
    aboutproduct,
    image,
    ogImage,
    inquiryLink
  } = productData;

  return (
      <React.Fragment>
        <Helmet>
          <title>{title}</title>
          <meta name="description" content={tagline} />
          <meta name="keywords" content="L.T. Panel, electrical distribution, power systems, high-quality panels, Trackzer Switchgears" />
          <meta property="og:title" content={title} />
          <meta property="og:description" content={tagline} />
          <meta property="og:image" content={ogImage} />
          <meta property="og:type" content="website" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
        </Helmet>

        <InnerSectionBanner {...bannerData} />

        <section className="product-details-main p-tb-80">
          <div className="container custom-container">
            <div className="row">
              <div className="col-md-12 product-details-card">
                <div className="row">
                  <div className="col-md-12 col-lg-6">
                    <div className="product-card">
                      <div className="product-thumbnail">
                        <img src={image} alt={title} className="product-card-image w-100" loading="lazy" />
                      </div>
                    </div>
                  </div>

                  <div className="col-md-12 col-lg-6">
                    <div className="product-details">
                      <h4 className="medium font-28 text-black mb-2">{title}</h4>
                      <p className="regular font-18 text-black-80">{tagline}</p>
                    </div>

                    <div className="product-details mt-15">
                      <div className="btn-red-features">Special Features</div>
                      <ul className="special-features">
                        {specialFeatures.map((feature, index) => (
                            <li key={index} className="regular font-16 text-black-80">{feature}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <div className="product-details">
                      <p className="regular font-18 text-black-80 mb-3">{aboutproduct}</p>
                      <a href={inquiryLink} className="btn-red inquiry" rel="noopener noreferrer">GET A QUOTE</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Relatedproducts />
        <Faq />
        <Clients />
        <Cta />
        <Testimonials />
      </React.Fragment>
  );
};

export default WaterSystemMccPanel;
