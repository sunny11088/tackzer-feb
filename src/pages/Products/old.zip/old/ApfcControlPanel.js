import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'APFC Control Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'APFC Control Panel' },
  ],
};

const productData = {
    "title": "APFC Control Panel",
    "tagline": "High Efficiency | Consistent Performance",
    "aboutproduct": "Our APFC Control Panels are designed to optimize the power factor of industrial systems, ensuring that capacitor banks are switched in and out automatically to maintain energy efficiency. These panels contribute to reducing energy costs and improving the overall stability of electrical systems by minimizing reactive power and enhancing the efficiency of electrical equipment.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Automatic Power Factor Correction for Optimal Efficiency",
        "Continuous and Steady Power Factor Maintenance",
        "In-Built Fuse Protection for Safety",
        "Advanced Capacitor Switching Mechanism",
        "Minimization of Harmonic Currents",
        "Tough Electrical Insulation to Ensure Durability",
        "High-Efficiency Components to Save Energy",
        "Customizable Designs to Meet Client Requirements",
        "Easy-to-Maintain with Long-Term Performance"
  ],
};

const ApfcControlPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>APFC Control Panel</title>
              <meta name="description" content="High Efficiency | Consistent Performance" />
              <meta name="keywords" content="APFC Control Panel, power factor correction, energy efficiency, automatic capacitor switching, harmonic currents, electrical insulation, high-efficiency components, customizable design" />
              <meta property="og:title" content="APFC Control Panel" />
              <meta property="og:description" content="Our APFC Control Panels are designed to optimize the power factor of industrial systems, ensuring that capacitor banks are switched in and out automatically to maintain energy efficiency." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default ApfcControlPanel;
