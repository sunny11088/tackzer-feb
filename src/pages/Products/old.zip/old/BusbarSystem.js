import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'Busbar System',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'Busbar System' },
  ],
};

const productData = {
    "title": "Busbar System",
    "tagline": "Distinguished Engineering with Advanced Features",
    "aboutproduct": "Our Electrical Busbar Systems provide a modular and highly efficient solution for power distribution within industrial and commercial buildings. These systems eliminate the need for individual cabling for each device, offering a streamlined approach to electrical wiring. Busbar systems are known for their durability, scalability, and ease of maintenance, making them an ideal choice for large-scale electrical installations.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Modular Design for Easy Installation and Scalability",
        "Efficient Power Distribution Across Multiple Devices",
        "Robust Construction for Long-Term Durability",
        "Reduces the Need for Individual Cables",
        "Simplifies Electrical Maintenance and Expansion",
        "Designed for High-Current Applications",
        "Ensures Safe and Reliable Power Distribution",
        "Compact Design for Space Optimization",
        "Meets Industry Standards for Quality and Safety"
  ],
};

const BusbarSystem = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>Busbar System</title>
              <meta name="description" content="Distinguished Engineering with Advanced Features" />
              <meta name="keywords" content="Busbar System, power distribution, modular design, high-current applications, efficient electrical system, safe distribution, space optimization" />
              <meta property="og:title" content="Busbar System" />
              <meta property="og:description" content="Our Electrical Busbar Systems provide a modular and highly efficient solution for power distribution within industrial and commercial buildings." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default BusbarSystem;
