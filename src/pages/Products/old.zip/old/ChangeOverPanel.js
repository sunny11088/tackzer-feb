import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'Change Over Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'Change Over Panel' },
  ],
};

const productData = {
    "title": "Change Over Panel",
    "tagline": "Auto/Manual Mode | Highly Reliable",
    "aboutproduct": "Our Change Over Panels are designed for seamless switching between different power sources, ensuring that electrical systems remain operational in the event of a power failure. These panels allow for both automatic and manual switching between electricity supplies, providing flexibility and reliability in applications where uninterrupted power is critical, such as hospitals, factories, and residential buildings.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Auto/Manual Mode Selector for Flexibility",
        "Automatic Generator Start with Delay Function",
        "Alarm and Fault Detection System",
        "Durable and Safe Construction for Emergency Use",
        "Easy to Install and Operate",
        "Protects Critical Systems from Power Failures",
        "Reliable and Proven in Various Applications",
        "Low Maintenance and Long-Lasting",
        "Essential for Standby Power Systems"
  ],
};

const ChangeOverPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>Change Over Panel</title>
              <meta name="description" content="Auto/Manual Mode | Highly Reliable" />
              <meta name="keywords" content="Change Over Panel, seamless switching, power sources, emergency use, generator start, alarm system, low maintenance, reliable performance, critical systems" />
              <meta property="og:title" content="Change Over Panel" />
              <meta property="og:description" content="Our Change Over Panels are designed for seamless switching between different power sources, ensuring that electrical systems remain operational in the event of a power failure." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default ChangeOverPanel;
