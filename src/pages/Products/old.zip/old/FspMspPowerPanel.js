import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'FSP-MSP Power Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'FSP-MSP Power Panel' },
  ],
};

const productData = {
    "title": "FSP-MSP Power Panel",
    "tagline": "Easy Operation | Reliable Performance",
    "aboutproduct": "Trackzer Switchgears Pvt. Ltd.'s FSP-MSP Power Panels are engineered for both residential and commercial applications, ensuring electrical safety and effective power distribution. These panels can accommodate a wide range of electrical components, such as circuit breakers, pump controllers, UPS systems, and stabilizers, providing a safe and reliable solution for managing power supplies. The FSP-MSP Power Panels are designed for optimal performance and ease of operation, ensuring that electrical systems run smoothly and efficiently.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Durable and Reliable Construction",
        "Accommodates a Wide Range of Electrical Components",
        "Ensures Safety and Operational Efficiency",
        "High-Performance Circuit Breakers for Protection",
        "Flexibility for Custom Applications",
        "Easy Installation and Maintenance",
        "Meets Industry Standards for Safety and Performance",
        "Enhanced Power Distribution and Control",
        "Designed for Both Residential and Commercial Use"
  ],
};

const FspMspPowerPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>FSP-MSP Power Panel</title>
              <meta name="description" content="Easy Operation | Reliable Performance" />
              <meta name="keywords" content="FSP-MSP Power Panel, electrical safety, power distribution, circuit breakers, reliable performance, residential, commercial applications, high-performance, flexible design" />
              <meta property="og:title" content="FSP-MSP Power Panel" />
              <meta property="og:description" content="Trackzer Switchgears Pvt. Ltd.'s FSP-MSP Power Panels are engineered for both residential and commercial applications, ensuring electrical safety and effective power distribution." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default FspMspPowerPanel;
