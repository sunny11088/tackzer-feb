import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'PCC Control Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'PCC Control Panel' },
  ],
};

const productData = {
    "title": "PCC Control Panel",
    "tagline": "Reliability and Design Performance",
    "aboutproduct": "Trackzer Switchgears Pvt. Ltd. specializes in designing and manufacturing PCC Control Panels that are crucial for managing and controlling the electrical power distribution in industrial applications. These panels ensure that electrical systems operate efficiently and reliably, providing the necessary control for power distribution and safeguarding against electrical faults. Our PCC Control Panels are engineered to meet industry standards, ensuring safety and operational excellence.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Customizable Designs Tailored to Specific Client Needs",
        "High-Quality Switchgears and Busbars",
        "Reliable Power Control and Distribution",
        "Optimal Performance for Industrial Applications",
        "Built with Strong and Durable Materials",
        "Easy-to-Operate Interface for Operators",
        "Highly Efficient and Maintenance-Free",
        "Protection Against Overcurrent and Faults",
        "Meets Global Standards for Electrical Safety"
  ],
};

const PccControlPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>PCC Control Panel</title>
              <meta name="description" content="Reliability and Design Performance" />
              <meta name="keywords" content="PCC Control Panel, electrical power distribution, industrial applications, customizable design, reliable power control, overcurrent protection, efficient panels, global safety standards" />
              <meta property="og:title" content="PCC Control Panel" />
              <meta property="og:description" content="Trackzer Switchgears Pvt. Ltd. specializes in designing and manufacturing PCC Control Panels that are crucial for managing and controlling the electrical power distribution in industrial applications." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default PccControlPanel;
