import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'PLC Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'PLC Panel' },
  ],
};

const productData = {
    "title": "PLC Panel",
    "tagline": "Advanced & Complex Engineering",
    "aboutproduct": "Trackzer Switchgears Pvt. Ltd. provides advanced PLC Panels that cater to the automation needs of residential, commercial, and industrial electrical systems. These panels support a wide range of electrical systems and integrate seamlessly with other control devices, providing precise automation and control. The PLC panels are designed for complex engineering tasks, ensuring high operational reliability and efficiency.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Precision Design for Automation Systems",
        "Supports a Range of Electrical Control Systems",
        "Highly Reliable and Durable for Continuous Operation",
        "Customizable to Meet Specific Automation Needs",
        "Advanced Fault Detection and Protection Features",
        "Enhances Operational Efficiency and Safety",
        "User-Friendly Interface for Easy Operation",
        "Ideal for Complex Industrial Applications",
        "Proven Technology for Long-Term Performance"
  ],
};

const PlcPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>PLC Panel</title>
              <meta name="description" content="Advanced & Complex Engineering" />
              <meta name="keywords" content="PLC Panel, automation systems, electrical control, reliability, fault detection, operational efficiency, customizable design, user-friendly interface" />
              <meta property="og:title" content="PLC Panel" />
              <meta property="og:description" content="Trackzer Switchgears Pvt. Ltd. provides advanced PLC Panels that cater to the automation needs of residential, commercial, and industrial electrical systems." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default PlcPanel;
