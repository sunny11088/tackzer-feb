import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'Power Control Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'Power Control Panel' },
  ],
};

const productData = {
    "title": "Power Control Panel",
    "tagline": "Widely Acclaimed | Hassle-Free Performance",
    "aboutproduct": "Our Power Control Panels combine advanced electrical devices for managing and controlling the mechanical functions of industrial equipment. These panels are extensively tested for reliability and performance, ensuring that they deliver seamless control and protection in various industrial environments. The panels can integrate with other electrical systems, optimizing operational efficiency and safety.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Advanced Electrical Devices for Effective Control",
        "Reliable Performance in Industrial Environments",
        "Easy to Operate and Maintain",
        "Customizable to Client Specifications",
        "Built-In Safety Mechanisms to Prevent Faults",
        "Designed for Heavy-Duty Industrial Applications",
        "High Efficiency and Performance",
        "Optimized for Long-Term Operation and Durability",
        "Meets Rigorous Industry Standards for Quality"
  ],
};

const PowerControlPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>Power Control Panel</title>
              <meta name="description" content="Widely Acclaimed | Hassle-Free Performance" />
              <meta name="keywords" content="Power Control Panel, electrical devices, industrial equipment, reliability, performance, customizable design, heavy-duty applications, safety mechanisms, long-term operation" />
              <meta property="og:title" content="Power Control Panel" />
              <meta property="og:description" content="Our Power Control Panels combine advanced electrical devices for managing and controlling the mechanical functions of industrial equipment. These panels are extensively tested for reliability and performance." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default PowerControlPanel;
