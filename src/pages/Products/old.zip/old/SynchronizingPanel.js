import React from 'react';
import { Helmet } from 'react-helmet';
import productImage from '../../../assets/img/common/about-img.png';  // New image
import Relatedproducts from "../../../components/Relatedproducts/Relatedproducts";
import InnerSectionBanner from "../../../components/Innersectionbanner/Innersectionbanner";
import bgImage from "../../../assets/img/common/banner/about-bg.png";
import logoIcons from "../../../assets/img/common/trackzer-white.svg";
import Faq from "../../../components/Faq/Faq";
import Clients from "../../../components/Clients/Clients";
import Cta from "../../../components/Cta/Cta";
import Testimonials from "../../../components/Testimonials/Testimonials";
import ProductDetailsMain from "../../../components/ProductDetailsMain/ProductDetailsMain";

const bannerData = {
  bgImage: bgImage,
  heading: 'Synchronizing Panel',
  breadcrumb: [
    { label: <img src={logoIcons} alt="trackzer" className="breadcrumb-logo" />, link: '/' },
    { label: 'Product', link: '/products' },
    { label: 'Synchronizing Panel' },
  ],
};

const productData = {
    "title": "Synchronizing Panel",
    "tagline": "Automatic Function | Balanced Supply",
    "aboutproduct": "Trackzer Switchgears Pvt. Ltd. offers Synchronizing Panels that provide seamless synchronization of multiple generators or breakers, ensuring that power supply remains balanced and uninterrupted. These panels are designed to automatically adjust the operation of connected generators to ensure continuous and stable power supply, making them ideal for critical applications that demand reliability.",
    "image": productImage,
    "ogImage": "ogImage",
    "inquiryLink": "https://example.com/static-link",
    "specialFeatures": [
        "Automatic Synchronization for Multiple Generators",
        "Manual Override for Flexibility and Control",
        "Designed for Continuous Power Supply",
        "Reduces Risk of Power Outages and System Failures",
        "Can Be Custom Configured for Different Generator Types",
        "Reliable and High-Performance Design",
        "Easy Integration with Existing Systems",
        "Advanced Control Mechanism for Precise Operation",
        "Ideal for Hospitals, Data Centers, and Industrial Plants"
  ],
};

const SynchronizingPanel = () => {
  return (
      <React.Fragment>
          <Helmet>
              <title>Synchronizing Panel</title>
              <meta name="description" content="Automatic Function | Balanced Supply" />
              <meta name="keywords" content="Synchronizing Panel, generator synchronization, power supply, continuous power, manual override, system integration, industrial power solutions, data centers, hospitals" />
              <meta property="og:title" content="Synchronizing Panel" />
              <meta property="og:description" content="Trackzer Switchgears Pvt. Ltd. offers Synchronizing Panels that provide seamless synchronization of multiple generators or breakers, ensuring that power supply remains balanced and uninterrupted." />
              <meta property="og:image" content="ogImage" />
              <meta property="og:type" content="website" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <meta name="inquiry-link" content="https://example.com/static-link" />
          </Helmet>

        <InnerSectionBanner {...bannerData} />

        <ProductDetailsMain
            image={productData.image}
            title={productData.title}
            tagline={productData.tagline}
            aboutproduct={productData.aboutproduct}
            inquiryLink={productData.inquiryLink}
            specialFeatures={productData.specialFeatures}
        />

        <Relatedproducts/>
        <Faq/>
        <Clients/>
        <Cta/>
        <Testimonials/>
      </React.Fragment>
  );
};

export default SynchronizingPanel;
